
public enum StateProduct {
    STOCK, AUCTION, SALES
}
